# Exercise 01 - Image Mapping using HTML

## Aim

To create a webpage that demonstrates image mapping by embedding a map in a web page, defining hotspots on the map, and displaying related information when hotspots are clicked.

## Procedure

1. Create an HTML file with basic tags.
2. Insert an image into the webpage using the `img` tag with the `src` attribute.
3. Define hotspots using the `area` tag with attributes such as `shape`, `coords`, and `href`.
4. Create individual HTML files containing information for each hotspot.
5. Link these HTML files via the `href` attribute inside each `area` tag.
6. Open the main HTML file in a browser to interact with the hotspots.

## How to Execute

- Open `Browsers.html` in any modern web browser.
- Click on any browser logo to view detailed information.

## Output

### Main Page Output
![Main Output](./Outputs/Browsers_output.png)

### Chrome Browser Output
![Chrome Output](./Outputs/Chrome_output.png)
